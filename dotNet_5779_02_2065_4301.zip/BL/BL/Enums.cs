﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO
{
    public enum GenderEnum { Male = 1, Female = 2 }
    public enum CarTypeEnum { MotorCycle = 1, PrivateCar, PrivateCarAuto, Truck12Tons, TruckUnlimited, Bus }
}
